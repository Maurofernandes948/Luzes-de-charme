import { Stat, GalleryItem } from './types';

export const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-AO', {
    style: 'currency',
    currency: 'AOA',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value).replace('AOA', 'KZ');
};

export const STATS: Stat[] = [
  { value: '500+', label: 'Clientes satisfeitos' },
  { value: '3+', label: 'Anos de experiência' },
  { value: '100%', label: 'Qualidade garantida' }
];

export const GALLERY: GalleryItem[] = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800&q=80',
    title: 'Coleção Sneakers Deluxe',
    tall: true
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&q=80',
    title: 'Alta Costura'
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=600&q=80',
    title: 'Acessórios Premium'
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=600&q=80',
    title: 'Lifestyle & Charme'
  },
  {
    id: 5,
    image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=900&q=80',
    title: 'Editorial de Moda',
    wide: true
  },
  {
    id: 6,
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=600&q=80',
    title: 'Urban Style'
  }
];

export const STORE_NAME = 'Luzes de Charme';
export const STORE_SLOGAN = 'Moda Premium';
export const STORE_DESCRIPTION = 'Tênis exclusivos, roupas sofisticadas e acessórios únicos. Encomende hoje — entrega em Luanda, Angola.';
export const STORE_NOTICE = '✦ Entrega disponível em Luanda, Angola | Pagamento seguro: 50% na encomenda + 50% na entrega ✦';
export const WHATSAPP_NUMBER = '244948987130';
export const WHATSAPP_DISPLAY = '+244 948 987 130';
export const STORE_CITY = 'Luanda, Angola';
export const INSTAGRAM_HANDLE = 'luzneidymanuel1234';
export const EMAIL_ADDRESS = 'luzesdecharme@gmail.com';
