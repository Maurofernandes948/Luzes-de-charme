import { GoogleGenAI } from "@google/genai";

async function cropImage(base64Image: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image,
            mimeType: 'image/png',
          },
        },
        {
          text: 'Crop this image to only include the white sneakers. Remove all UI elements like the WhatsApp header, the black background, and the navigation arrows. Return ONLY the cropped image of the sneakers.',
        },
      ],
    },
  });
  
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return part.inlineData.data;
    }
  }
  return null;
}
